from __future__ import annotations

import json
import unittest
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, PngImagePlugin

from testinsight.analysis import score_measurements
from testinsight.image_parser import extract_image
from testinsight.io import load_measurements
from testinsight.log_parser import parse_log

PROJECT = Path(__file__).resolve().parents[1]


class CoreTests(unittest.TestCase):
    def test_mixed_timestamp_and_alias_ingestion(self):
        path = PROJECT / "runtime" / "test-work" / "mixed.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            "Timestamp,Signal Strength (dBm),Data Throughput (Mbps),Latency (ms),Network Type\n"
            "2026-01-01 00:00:00,-90,55,30,5G\n"
            "2026-01-01 00:00:00.100000,-91,54,31,5G\n", encoding="utf-8")
        frame = load_measurements(path)
        self.assertEqual(len(frame), 2)
        self.assertIn("throughput_mbps", frame.columns)

    def test_threshold_decision(self):
        frame = pd.DataFrame({
            "network_type": ["5G", "5G"], "signal_strength_dbm": [-90, -110],
            "throughput_mbps": [80, 5], "latency_ms": [20, 100],
        })
        rules = {"5G": {"signal_strength_dbm_min": -100, "throughput_mbps_min": 50, "latency_ms_max": 40}}
        result = score_measurements(frame, rules)
        self.assertEqual(result["status"].tolist(), ["PASS", "FAIL"])

    def test_log_parsing_and_rejection_count(self):
        path = PROJECT / "runtime" / "test-work" / "parser.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            '[2026-01-01T00:00:00Z] ERROR test_id=TC-1 code=LATENCY_TIMEOUT metric=latency_ms value=120 message="Latency timeout"\n'
            "old unsupported record\n", encoding="utf-8")
        events, unmatched = parse_log(path)
        self.assertEqual(len(events), 1)
        self.assertEqual(unmatched, 1)
        self.assertEqual(events[0].root_cause, "Transport latency")

    def test_image_visual_status_and_metadata(self):
        path = PROJECT / "runtime" / "test-work" / "result.png"
        path.parent.mkdir(parents=True, exist_ok=True)
        image = Image.new("RGB", (1000, 560), "white")
        ImageDraw.Draw(image).rectangle((700, 34, 950, 140), fill="#16845b")
        meta = PngImagePlugin.PngInfo()
        meta.add_text("test_result_json", json.dumps({
            "test_id": "TC-1", "network_type": "5G", "throughput_mbps": 82.0, "latency_ms": 19.0,
        }))
        image.save(path, pnginfo=meta)
        result = extract_image(path)
        self.assertEqual(result.status, "PASS")
        self.assertEqual(result.test_id, "TC-1")


if __name__ == "__main__":
    unittest.main()
