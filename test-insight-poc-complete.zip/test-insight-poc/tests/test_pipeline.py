from __future__ import annotations

import unittest
from pathlib import Path

from testinsight.pipeline import process


PROJECT = Path(__file__).resolve().parents[1]


class PipelineTests(unittest.TestCase):
    def test_demo_end_to_end(self):
        output = PROJECT / "runtime" / "test-work" / "pipeline"
        output.mkdir(parents=True, exist_ok=True)
        result = process(PROJECT / "data" / "demo", output, PROJECT / "config" / "thresholds.json")
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["summary"]["total_samples"], 1200)
        self.assertEqual(result["evaluation"]["log_extraction_accuracy_pct"], 100.0)
        self.assertTrue((output / "test_report.html").exists())


if __name__ == "__main__":
    unittest.main()
