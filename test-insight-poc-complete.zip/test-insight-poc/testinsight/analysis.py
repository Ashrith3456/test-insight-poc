from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def load_thresholds(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def score_measurements(frame: pd.DataFrame, thresholds: dict) -> pd.DataFrame:
    df = frame.copy()
    df["signal_pass"] = False
    df["throughput_pass"] = False
    df["latency_pass"] = False
    for network, rule in thresholds.items():
        mask = df["network_type"].eq(network.upper())
        df.loc[mask, "signal_pass"] = df.loc[mask, "signal_strength_dbm"] >= rule["signal_strength_dbm_min"]
        df.loc[mask, "throughput_pass"] = df.loc[mask, "throughput_mbps"] >= rule["throughput_mbps_min"]
        df.loc[mask, "latency_pass"] = df.loc[mask, "latency_ms"] <= rule["latency_ms_max"]
    df["status"] = np.where(df[["signal_pass", "throughput_pass", "latency_pass"]].all(axis=1), "PASS", "FAIL")
    # Robust, explainable anomaly score based on median absolute deviation.
    # Compare like with like: each radio technology has a different expected
    # performance envelope, so robust z-scores are calculated per technology.
    df["anomaly_score"] = 0.0
    for _, indexes in df.groupby("network_type").groups.items():
        scores = []
        part = df.loc[indexes]
        for col in ("signal_strength_dbm", "throughput_mbps", "latency_ms"):
            median = part[col].median()
            mad = np.median(np.abs(part[col] - median)) or 1.0
            scores.append(np.abs(0.6745 * (part[col] - median) / mad))
        df.loc[indexes, "anomaly_score"] = np.max(np.vstack(scores), axis=0).round(3)
    df["is_anomaly"] = df["anomaly_score"] > 3.5
    return df


def summarize(df: pd.DataFrame) -> dict:
    by_network = []
    for network, part in df.groupby("network_type", sort=True):
        hours = (part["timestamp"] - part["timestamp"].min()).dt.total_seconds() / 3600
        throughput_trend = float(np.polyfit(hours, part["throughput_mbps"], 1)[0]) if hours.nunique() > 1 else 0.0
        latency_trend = float(np.polyfit(hours, part["latency_ms"], 1)[0]) if hours.nunique() > 1 else 0.0
        by_network.append({
            "network_type": network,
            "samples": int(len(part)),
            "pass_rate_pct": round(float(part["status"].eq("PASS").mean() * 100), 2),
            "throughput_mean_mbps": round(float(part["throughput_mbps"].mean()), 2),
            "throughput_p95_mbps": round(float(part["throughput_mbps"].quantile(.95)), 2),
            "latency_mean_ms": round(float(part["latency_ms"].mean()), 2),
            "latency_p95_ms": round(float(part["latency_ms"].quantile(.95)), 2),
            "signal_mean_dbm": round(float(part["signal_strength_dbm"].mean()), 2),
            "throughput_trend_mbps_per_hour": round(throughput_trend, 4),
            "latency_trend_ms_per_hour": round(latency_trend, 4),
            "anomalies": int(part["is_anomaly"].sum()),
        })
    return {
        "total_samples": int(len(df)),
        "pass_count": int(df["status"].eq("PASS").sum()),
        "fail_count": int(df["status"].eq("FAIL").sum()),
        "pass_rate_pct": round(float(df["status"].eq("PASS").mean() * 100), 2),
        "anomaly_count": int(df["is_anomaly"].sum()),
        "period_start": df["timestamp"].min().isoformat(),
        "period_end": df["timestamp"].max().isoformat(),
        "by_network": by_network,
    }
