from __future__ import annotations

import re
from pathlib import Path

from .models import LogEvent


LINE = re.compile(
    r"^\[(?P<timestamp>[^]]+)]\s+(?P<level>DEBUG|INFO|WARN|ERROR|CRITICAL)\s+"
    r"test_id=(?P<test_id>\S+)\s+code=(?P<code>\S+)"
    r"(?:\s+metric=(?P<metric>\S+)\s+value=(?P<value>-?[\d.]+))?\s+message=\"(?P<message>.*)\"$"
)

CAUSES = (
    (re.compile(r"timeout|latency", re.I), "Transport latency"),
    (re.compile(r"weak signal|rsrp|signal", re.I), "Radio signal degradation"),
    (re.compile(r"throughput|bandwidth", re.I), "Throughput degradation"),
    (re.compile(r"connection|unreachable|socket", re.I), "Connectivity failure"),
    (re.compile(r"calibration|instrument", re.I), "Test equipment"),
)


def infer_root_cause(code: str, message: str) -> str:
    text = f"{code} {message}"
    for pattern, cause in CAUSES:
        if pattern.search(text):
            return cause
    return "Unclassified"


def parse_log(path: str | Path) -> tuple[list[LogEvent], int]:
    events: list[LogEvent] = []
    unmatched = 0
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        if not raw.strip():
            continue
        match = LINE.match(raw.strip())
        if not match:
            unmatched += 1
            continue
        item = match.groupdict()
        events.append(LogEvent(
            timestamp=item["timestamp"], level=item["level"], test_id=item["test_id"],
            code=item["code"], metric=item["metric"],
            value=float(item["value"]) if item["value"] is not None else None,
            message=item["message"], root_cause=infer_root_cause(item["code"], item["message"]),
        ))
    return events, unmatched


def parse_logs(paths: list[Path]) -> tuple[list[LogEvent], int]:
    all_events: list[LogEvent] = []
    unmatched = 0
    for path in paths:
        events, rejected = parse_log(path)
        all_events.extend(events)
        unmatched += rejected
    return all_events, unmatched

