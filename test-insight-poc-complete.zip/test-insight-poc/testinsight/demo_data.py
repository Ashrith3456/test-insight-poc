from __future__ import annotations

import json
import random
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont, PngImagePlugin

from .analysis import load_thresholds, score_measurements
from .io import load_measurements, write_json


def _font(size: int):
    candidates = [Path("C:/Windows/Fonts/segoeui.ttf"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def _result_image(row: pd.Series, test_id: str, path: Path) -> dict:
    status = row["status"]
    image = Image.new("RGB", (1000, 560), "#f4f7fb")
    draw = ImageDraw.Draw(image)
    navy, muted = "#101d35", "#5d6a7d"
    draw.rounded_rectangle((35, 30, 965, 530), radius=24, fill="white", outline="#d9e1ec", width=2)
    draw.text((75, 65), "RADIO VERIFICATION RESULT", fill=navy, font=_font(30))
    color = "#16845b" if status == "PASS" else "#cf3f4f"
    draw.rounded_rectangle((730, 58, 915, 143), radius=18, fill=color)
    draw.text((775, 80), status, fill="white", font=_font(31))
    items = [
        ("Test ID", test_id), ("Network", str(row["network_type"])),
        ("Signal", f"{row['signal_strength_dbm']:.2f} dBm"),
        ("Throughput", f"{row['throughput_mbps']:.2f} Mbps"),
        ("Latency", f"{row['latency_ms']:.2f} ms"),
        ("Location", str(row.get("location", "unknown"))),
    ]
    y = 185
    for label, value in items:
        draw.text((80, y), label.upper(), fill=muted, font=_font(17))
        draw.text((285, y - 3), value, fill=navy, font=_font(22))
        y += 48
    draw.line((75, 485, 925, 485), fill="#d9e1ec", width=2)
    draw.text((75, 497), "Synthetic companion image generated for TestInsight POC", fill=muted, font=_font(15))
    payload = {
        "test_id": test_id, "status": status, "network_type": row["network_type"],
        "throughput_mbps": round(float(row["throughput_mbps"]), 3),
        "latency_ms": round(float(row["latency_ms"]), 3),
    }
    metadata = PngImagePlugin.PngInfo()
    metadata.add_text("test_result_json", json.dumps(payload))
    image.save(path, pnginfo=metadata)
    return payload


def generate_demo(source: str | Path, output: str | Path, thresholds_path: str | Path, rows: int = 1200) -> dict:
    output = Path(output)
    for folder in ("measurements", "logs", "images"):
        (output / folder).mkdir(parents=True, exist_ok=True)
    source_df = load_measurements(source)
    sample = source_df.iloc[: min(rows, len(source_df))].copy().reset_index(drop=True)
    sample.insert(0, "test_id", [f"TC-{i + 1:05d}" for i in range(len(sample))])
    scored = score_measurements(sample, load_thresholds(thresholds_path))
    raw_columns = [c for c in sample.columns]
    sample[raw_columns].to_csv(output / "measurements" / "radio_measurements.csv", index=False)

    rng = random.Random(42)
    log_truth, image_truth = [], []
    with (output / "logs" / "verification.log").open("w", encoding="utf-8") as handle:
        for i, row in scored.iterrows():
            test_id = row["test_id"]
            stamp = row["timestamp"].isoformat()
            if row["status"] == "PASS":
                level, code, metric, value, message = "INFO", "TEST_OK", "throughput", row["throughput_mbps"], "Verification completed within configured limits"
            elif not row["latency_pass"]:
                level, code, metric, value, message = "ERROR", "LATENCY_TIMEOUT", "latency_ms", row["latency_ms"], "Latency timeout exceeded during transport verification"
            elif not row["throughput_pass"]:
                level, code, metric, value, message = "WARN", "LOW_THROUGHPUT", "throughput_mbps", row["throughput_mbps"], "Throughput below expected bandwidth threshold"
            else:
                level, code, metric, value, message = "WARN", "WEAK_SIGNAL", "signal_dbm", row["signal_strength_dbm"], "Weak signal detected by radio instrument"
            handle.write(f'[{stamp}] {level} test_id={test_id} code={code} metric={metric} value={value:.3f} message="{message}"\n')
            log_truth.append({"test_id": test_id, "level": level, "code": code})
            if i < 24:
                image_truth.append(_result_image(row, test_id, output / "images" / f"{test_id}.png"))
        handle.write("legacy free-form line intentionally retained to measure parser rejection\n")
    truth = {"seed": 42, "source": "Kaggle Cellular Network Analysis Dataset + generated companions", "logs": log_truth, "images": image_truth}
    write_json(output / "ground_truth.json", truth)
    return {"rows": len(sample), "logs": len(log_truth), "images": len(image_truth), "output": str(output)}
