"""TestInsight: multimodal verification-test reporting POC."""

__version__ = "0.1.0"

