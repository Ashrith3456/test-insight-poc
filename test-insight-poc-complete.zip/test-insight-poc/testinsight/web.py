from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from jinja2 import Environment, FileSystemLoader

from .pipeline import process


PROJECT = Path(__file__).resolve().parent.parent
RUNTIME = PROJECT / "runtime"
LATEST = RUNTIME / "latest"
THRESHOLDS = PROJECT / "config" / "thresholds.json"
TEMPLATES = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"))
ALLOWED = {".csv", ".json", ".log", ".txt", ".png", ".jpg", ".jpeg"}
app = FastAPI(title="TestInsight", version="0.1.0")


@app.get("/", response_class=HTMLResponse)
def home():
    return TEMPLATES.get_template("app.html").render()


@app.get("/health")
def health():
    return {"status": "ok", "report_ready": (LATEST / "test_report.html").exists()}


@app.get("/report")
def report():
    path = LATEST / "test_report.html"
    if not path.exists():
        raise HTTPException(404, "No report has been generated yet.")
    return FileResponse(path, media_type="text/html")


@app.get("/download/report")
def download_report():
    path = LATEST / "test_report.html"
    if not path.exists():
        raise HTTPException(404, "No report has been generated yet.")
    return FileResponse(path, media_type="text/html", filename="TestInsight_Verification_Report.html")


@app.get("/api/summary")
def api_summary():
    path = LATEST / "summary.json"
    if not path.exists():
        raise HTTPException(404, "No summary has been generated yet.")
    return FileResponse(path, media_type="application/json")


@app.post("/upload")
async def upload(files: list[UploadFile] = File(...)):
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    batch = RUNTIME / "uploads" / stamp
    for folder in ("measurements", "logs", "images"):
        (batch / folder).mkdir(parents=True, exist_ok=True)
    saved = 0
    for item in files:
        suffix = Path(item.filename or "").suffix.lower()
        if suffix not in ALLOWED:
            continue
        safe_name = Path(item.filename or f"upload{suffix}").name
        folder = "measurements" if suffix in {".csv", ".json"} else "logs" if suffix in {".log", ".txt"} else "images"
        target = batch / folder / safe_name
        with target.open("wb") as handle:
            shutil.copyfileobj(item.file, handle)
        saved += 1
    if not saved:
        raise HTTPException(400, "No supported files uploaded.")
    try:
        process(batch, LATEST, THRESHOLDS)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(400, str(exc)) from exc
    return RedirectResponse("/", status_code=303)
