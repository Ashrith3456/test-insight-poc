from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd


ALIASES = {
    "timestamp": "timestamp",
    "date_index": "timestamp",
    "locality": "location",
    "location": "location",
    "signal strength (dbm)": "signal_strength_dbm",
    "signal_strength_dbm": "signal_strength_dbm",
    "rsrp": "signal_strength_dbm",
    "data throughput (mbps)": "throughput_mbps",
    "throughput_mbps": "throughput_mbps",
    "latency (ms)": "latency_ms",
    "latency_ms": "latency_ms",
    "network type": "network_type",
    "network_type": "network_type",
}

REQUIRED = {"timestamp", "signal_strength_dbm", "throughput_mbps", "latency_ms", "network_type"}


def _canonical(name: str) -> str:
    clean = re.sub(r"\s+", " ", name.strip().lower())
    return ALIASES.get(clean, re.sub(r"[^a-z0-9]+", "_", clean).strip("_"))


def load_measurements(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        frame = pd.read_csv(path)
    elif path.suffix.lower() == ".json":
        frame = pd.read_json(path)
    else:
        raise ValueError(f"Unsupported measurement format: {path.suffix}. Use CSV or JSON.")
    frame = frame.rename(columns={c: _canonical(str(c)) for c in frame.columns})
    missing = REQUIRED - set(frame.columns)
    if missing:
        raise ValueError(f"Missing required measurement columns: {', '.join(sorted(missing))}")
    # ``mixed`` accepts instrument streams that alternate whole-second and
    # fractional-second ISO timestamps (common in exported verification data).
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="coerce", utc=True, format="mixed")
    for col in ("signal_strength_dbm", "throughput_mbps", "latency_ms"):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame["network_type"] = frame["network_type"].astype(str).str.upper()
    frame = frame.dropna(subset=list(REQUIRED)).sort_values("timestamp").reset_index(drop=True)
    return frame


def read_json(path: str | Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


def write_json(path: str | Path, value) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")
