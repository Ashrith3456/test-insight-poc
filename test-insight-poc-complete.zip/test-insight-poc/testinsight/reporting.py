from __future__ import annotations

import html
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from jinja2 import Environment, FileSystemLoader, select_autoescape
from plotly.offline import get_plotlyjs


COLORS = {"navy": "#0c1d37", "blue": "#2070d6", "cyan": "#22b8cf", "green": "#16845b", "red": "#cf3f4f"}


def _style(fig, title: str):
    fig.update_layout(
        title=title, paper_bgcolor="white", plot_bgcolor="white", font={"family": "Segoe UI, sans-serif", "color": "#20304a"},
        margin={"l": 45, "r": 25, "t": 65, "b": 45}, height=370,
        legend={"orientation": "h", "y": 1.02, "x": 1, "xanchor": "right"},
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="#e9eef5")
    return fig


def build_charts(df: pd.DataFrame) -> list[str]:
    stride = max(1, len(df) // 600)
    trend = px.line(df.iloc[::stride], x="timestamp", y="throughput_mbps", color="network_type")
    latency = px.box(df, x="network_type", y="latency_ms", color="network_type", points=False)
    counts = df["status"].value_counts().reindex(["PASS", "FAIL"], fill_value=0)
    donut = go.Figure(go.Pie(labels=counts.index, values=counts.values, hole=.68, marker_colors=[COLORS["green"], COLORS["red"]]))
    scatter_df = df.iloc[::stride].copy()
    scatter = px.scatter(scatter_df, x="signal_strength_dbm", y="throughput_mbps", color="network_type", symbol="is_anomaly", hover_data=["latency_ms", "status"])
    figures = [
        _style(trend, "Throughput trend"), _style(latency, "Latency distribution by network"),
        _style(donut, "Threshold result distribution"), _style(scatter, "Signal vs throughput and anomalies"),
    ]
    return [fig.to_html(full_html=False, include_plotlyjs=False, config={"displaylogo": False, "responsive": True}) for fig in figures]


def render_report(output: str | Path, df: pd.DataFrame, summary: dict, events: list[dict], images: list[dict], evaluation: dict) -> Path:
    output = Path(output)
    env = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"), autoescape=select_autoescape())
    template = env.get_template("report.html")
    failures = df[df["status"].eq("FAIL")].sort_values("anomaly_score", ascending=False).head(20).copy()
    columns = ["test_id", "timestamp", "network_type", "signal_strength_dbm", "throughput_mbps", "latency_ms", "anomaly_score", "status"]
    columns = [c for c in columns if c in failures.columns]
    report = template.render(
        generated_at=datetime.now(timezone.utc).isoformat(), summary=summary, charts=build_charts(df),
        network_rows=summary["by_network"], failures=failures[columns].to_dict("records"),
        events=events[:30], images=images, evaluation=evaluation, plotly_js=get_plotlyjs(),
    )
    path = output / "test_report.html"
    path.write_text(report, encoding="utf-8")
    return path

