from __future__ import annotations

import argparse
import json
from pathlib import Path


PROJECT = Path(__file__).resolve().parent.parent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="test-insight", description="Automated verification-test analysis POC")
    commands = parser.add_subparsers(dest="command", required=True)
    demo = commands.add_parser("generate-demo", help="Create correlated mock logs and images from measurement data")
    demo.add_argument("--source", required=True)
    demo.add_argument("--output", default=str(PROJECT / "data" / "demo"))
    demo.add_argument("--rows", type=int, default=1200)
    run = commands.add_parser("process", help="Process measurement, log and image inputs")
    run.add_argument("--input", default=str(PROJECT / "data" / "demo"))
    run.add_argument("--output", default=str(PROJECT / "runtime" / "latest"))
    serve = commands.add_parser("serve", help="Run the local web application")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    thresholds = PROJECT / "config" / "thresholds.json"
    if args.command == "generate-demo":
        from .demo_data import generate_demo
        result = generate_demo(args.source, args.output, thresholds, args.rows)
    elif args.command == "process":
        from .pipeline import process
        result = process(args.input, args.output, thresholds)
    else:
        import uvicorn
        uvicorn.run("testinsight.web:app", host=args.host, port=args.port, reload=False)
        return
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()

