from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

from .models import ImageResult


def _visual_status(image: Image.Image) -> tuple[str, float]:
    """Classify the top-right status badge by color; independent of PNG metadata."""
    rgb = np.asarray(image.convert("RGB"))
    h, w, _ = rgb.shape
    crop = rgb[int(h * .06):int(h * .25), int(w * .70):int(w * .95)]
    red = ((crop[:, :, 0] > 150) & (crop[:, :, 1] < 130)).mean()
    green = ((crop[:, :, 1] > 115) & (crop[:, :, 0] < 100)).mean()
    if green > red and green > .08:
        return "PASS", round(float(min(0.99, .65 + green)), 3)
    if red > .08:
        return "FAIL", round(float(min(0.99, .65 + red)), 3)
    return "UNKNOWN", 0.2


def extract_image(path: str | Path) -> ImageResult:
    path = Path(path)
    with Image.open(path) as image:
        status, visual_confidence = _visual_status(image)
        raw = image.info.get("test_result_json")
        if raw:
            try:
                data = json.loads(raw)
                # Status is deliberately obtained from pixels, while structured values
                # come from embedded instrument metadata when present.
                return ImageResult(
                    file=path.name, test_id=data.get("test_id"), status=status,
                    network_type=data.get("network_type"),
                    throughput_mbps=float(data["throughput_mbps"]) if data.get("throughput_mbps") is not None else None,
                    latency_ms=float(data["latency_ms"]) if data.get("latency_ms") is not None else None,
                    confidence=visual_confidence, method="visual badge + PNG instrument metadata",
                )
            except (ValueError, TypeError, json.JSONDecodeError):
                pass
        return ImageResult(
            file=path.name, test_id=None, status=status, network_type=None,
            throughput_mbps=None, latency_ms=None, confidence=visual_confidence,
            method="visual badge only (OCR adapter required for text fields)",
        )


def extract_images(paths: list[Path]) -> list[ImageResult]:
    results = []
    for path in paths:
        try:
            results.append(extract_image(path))
        except OSError:
            results.append(ImageResult(path.name, None, "ERROR", None, None, None, 0.0, "unreadable image"))
    return results

