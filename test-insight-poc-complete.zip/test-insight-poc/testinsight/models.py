from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class LogEvent:
    timestamp: str
    level: str
    test_id: str
    code: str
    metric: str | None
    value: float | None
    message: str
    root_cause: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ImageResult:
    file: str
    test_id: str | None
    status: str
    network_type: str | None
    throughput_mbps: float | None
    latency_ms: float | None
    confidence: float
    method: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

