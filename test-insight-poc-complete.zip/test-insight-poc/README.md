# TestInsight POC

TestInsight is an end-to-end proof of concept for automated verification-test data processing. It combines numerical measurements, raw logs, and image-based results into threshold decisions, statistical summaries, interactive visualizations, structured result tables, and a predefined test report.

This is a portfolio/research POC built from public and synthetic data. It contains no Ericsson-confidential information and is not an Ericsson product.

## What is included

- CSV/JSON numerical ingestion with schema normalization and validation
- Configurable PASS/FAIL rules by network technology
- Explainable robust anomaly detection (median absolute deviation per technology)
- Regex-based log extraction and root-cause categorization
- Image status detection from pixels plus extraction of embedded instrument metadata
- Generated mock screenshots and logs correlated to real public telecom measurements
- Interactive throughput, latency, pass/fail, and anomaly charts
- Automated HTML report population and CSV/JSON result tables
- Ground-truth accuracy, runtime, throughput, and POC usability-readiness evaluation
- Browser upload interface, JSON summary API, health endpoint, and batch CLI
- Unit and end-to-end tests
- Deployment, security, OCR, evaluation, and Ericsson-integration recommendations

## Data provenance

The measurement data is the **Cellular Network Analysis Dataset** published on Kaggle by Suraj520 under **CC0 / Public Domain**:

- Dataset: https://www.kaggle.com/datasets/suraj520/cellular-network-analysis-dataset
- Local source: `data/kaggle/signal_metrics.csv`
- Downloaded: 2026-09-23 through Kaggle's public dataset API

The companion `.log` files, PNG result cards, test IDs, and ground-truth labels are generated locally by `testinsight.demo_data` from those measurements. They are clearly synthetic and reproducible (`seed = 42`). The public dataset itself is described by its publisher as realistic/generated telecom measurements; it is not Ericsson verification data.

## Quick start

Python 3.11 or newer is required.

```powershell
cd "C:\path\to\test-insight-poc"
python -m pip install -r requirements.txt
python -m testinsight process --input data\demo --output runtime\latest
python -m testinsight serve
```

Open http://127.0.0.1:8000. The included demo report is already generated at `runtime/latest/test_report.html` and works offline.

Container option:

```powershell
docker build -t test-insight-poc .
docker run --rm -p 8000:8000 test-insight-poc
```

To regenerate every mock companion artifact:

```powershell
python -m testinsight generate-demo --source data\kaggle\signal_metrics.csv --output data\demo --rows 1200
python -m testinsight process --input data\demo --output runtime\latest
```

To run tests:

```powershell
python -m unittest discover -s tests -v
```

## Input contract

Place files under one batch directory:

```text
batch/
├── measurements/    # CSV or JSON; at least one is required
├── logs/            # .log or .txt; optional
├── images/          # .png, .jpg, .jpeg; optional
└── ground_truth.json  # optional, enables accuracy metrics
```

Required canonical measurement fields are:

| Field | Type | Meaning |
|---|---|---|
| `timestamp` | ISO date/time | Measurement time |
| `network_type` | text | 3G, 4G, LTE, or 5G |
| `signal_strength_dbm` | number | Received signal strength |
| `throughput_mbps` | number | Measured data throughput |
| `latency_ms` | number | Round-trip/test latency |

The loader also maps Kaggle's display names and `rsrp` to these canonical fields. Add aliases in `testinsight/io.py` for real export formats.

The supported structured log line is:

```text
[2026-01-01T10:00:00Z] ERROR test_id=TC-001 code=LATENCY_TIMEOUT metric=latency_ms value=122.4 message="Latency timeout exceeded"
```

Malformed lines are counted and retained as an evaluation signal rather than silently treated as valid.

## Architecture

```mermaid
flowchart LR
  A[CSV / JSON measurements] --> D[Schema normalization]
  B[Text logs] --> E[Event and cause extraction]
  C[Test-result images] --> F[Visual status + metadata adapter]
  D --> G[Rules + robust anomaly analysis]
  E --> H[Unified evidence model]
  F --> H
  G --> H
  H --> I[Charts and statistical summaries]
  H --> J[CSV / JSON result tables]
  I --> K[Predefined HTML report]
  J --> K
  H --> L[Accuracy, efficiency, usability evaluation]
```

The processing modules are independent of FastAPI. The same `process()` function powers the CLI and web application, which keeps analysis reproducible and makes later integration with schedulers or CI straightforward.

## JD requirement traceability

| Job-description requirement | POC implementation | Evidence |
|---|---|---|
| Analyse numerical, textual, and image formats | Schema loader, log parser, PNG/JPEG adapter | `testinsight/io.py`, `log_parser.py`, `image_parser.py` |
| Design and develop an automated application | Modular pipeline, CLI, web UI, API | `pipeline.py`, `cli.py`, `web.py` |
| Graphs, trends, and statistical summaries | Four interactive Plotly charts and per-technology descriptive statistics | Generated report and `reporting.py` |
| Investigate extracting text and image results | Regex/root-cause pipeline; visual, metadata, and OCR strategy comparison | `docs/METHODS_AND_DEPLOYMENT.md` |
| Populate predefined reports and result tables | Jinja HTML template plus four CSV tables and JSON manifest | `templates/report.html`, `runtime/latest/` |
| Evaluate accuracy, efficiency, and usability | Ground-truth extraction metrics, timed throughput, six-item usability heuristic | `summary.json`, report, evaluation documentation |
| Demonstrate with Ericsson verification data | Import contract and adapter seam are ready; blocked until authorized anonymized Ericsson samples are supplied | `docs/ERICSSON_PILOT_CHECKLIST.md` |
| Findings and future recommendations | Report section and deployment analysis | Report and `docs/METHODS_AND_DEPLOYMENT.md` |

The only item that cannot truthfully be completed without Ericsson is validation on its real verification data. The included public-data demonstration exercises the same path without claiming to be Ericsson evidence.

## Outputs

Each pipeline run creates:

- `test_report.html` — populated, self-contained interactive report
- `processed_results.csv` — row-level measurements, decisions, and anomaly scores
- `network_summary.csv` — statistical result table
- `extracted_log_events.csv` — structured log evidence
- `extracted_image_results.csv` — structured image evidence
- `summary.json` — headline metrics and evaluation
- `manifest.json` — run status, paths, summary, and evaluation

## Configuration and extension

Acceptance limits are intentionally externalized in `config/thresholds.json`. They are demonstration values, not telecom specifications. Real deployment requires versioned, approved thresholds tied to test-suite and product revisions.

Extension points:

- Add column aliases or new readers in `io.py`.
- Add log grammars and cause rules in `log_parser.py`.
- Add approved OCR/model adapters in `image_parser.py`.
- Add organization-specific fields to `templates/report.html`.
- Replace local run storage with controlled object/document storage.

## Important limitations

- Demonstration thresholds have not been validated by domain experts.
- Perfect mock extraction accuracy shows pipeline correctness on the generated format, not generalization to uncontrolled screenshots or logs.
- PNG metadata is a deterministic stand-in for instrument-export metadata. Screenshot-only text requires OCR.
- The web upload route is suitable for a local POC, not public exposure: production needs authentication, malware scanning, quotas, encryption, retention, and audit controls.
- The heuristic usability score is not a substitute for a System Usability Scale study with verification engineers.
