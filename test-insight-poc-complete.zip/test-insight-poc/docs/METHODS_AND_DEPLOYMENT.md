# Methods, findings, and deployment recommendation

## Extraction-method investigation

### Numerical measurements

**Selected for the POC:** deterministic schema mapping, type coercion, missing-value rejection, configurable threshold rules, and robust median-absolute-deviation anomaly scoring within each network technology.

This is preferable to a black-box classifier for the initial pilot because decisions are inspectable, ground truth is scarce, and technology-specific distributions differ materially. A supervised model becomes appropriate only after Ericsson supplies labelled historical outcomes and a cost model for false passes and false failures.

### Text logs

| Method | Strength | Limitation | Recommended use |
|---|---|---|---|
| Regex/grammar | Fast, deterministic, auditable | Requires known formats | Primary path for stable instrument logs |
| Keyword/rule classification | Explainable root-cause grouping | Synonyms require maintenance | POC and operational baseline |
| Template mining (Drain-style) | Finds recurring structures | Needs representative volume | Discovery of new log families |
| Embeddings/LLM | Handles varied language | Privacy, cost, non-determinism | Optional on-prem enrichment, never sole PASS/FAIL authority |

The POC uses the first two and records unmatched lines. The production parser should use a versioned registry keyed by tool, firmware, and log format.

### Test-result images

| Method | Suitable for | Risk |
|---|---|---|
| Embedded metadata/API | Instrument-generated exports | Not present in screenshots |
| Fixed-region visual detection | Stable PASS/FAIL badges, LEDs, gauges | Breaks when layout changes |
| OCR | Labels and numeric values | Font, resolution, locale, and decimal errors |
| Object detection/layout model | Many evolving layouts | Labelling and model-governance cost |

The POC reads structured PNG instrument metadata and independently detects the PASS/FAIL badge from pixels. For real screenshot-only evidence, implement an offline OCR adapter (for example an organization-approved Tesseract/PaddleOCR service), constrain OCR to configured regions, validate units and ranges, and send low-confidence results to human review. Image extraction should never silently make a pass decision when confidence or required fields are missing.

## Evaluation design

The generated logs and images have known ground truth. Evaluation reports exact log tuple recovery, image status accuracy, image-field accuracy, elapsed runtime, and files per second. A single malformed log line is included intentionally to prove rejection accounting.

The POC usability-readiness heuristic checks that it has:

1. A browser batch-upload path.
2. A CLI for automation.
3. Clear error messages for invalid schema/input.
4. A downloadable human-readable report.
5. Machine-readable CSV/JSON outputs.
6. Externalized thresholds rather than hidden decision rules.

This is reported as readiness, not user satisfaction. The pilot should recruit at least five representative verification engineers, run common tasks, record completion/error rates and time-on-task, and administer the 10-item System Usability Scale.

For Ericsson validation, build a blinded labelled set spanning products, tools, firmware versions, languages, image resolutions, PASS/FAIL balance, and rare failure modes. Report precision/recall per extracted field and status class—not only overall accuracy. Define a zero-tolerance policy for false PASS decisions or route every uncertain result to review.

## Findings from the public-data demonstration

- Technology distributions differ strongly, so global anomaly detection is misleading. The implementation therefore scores anomalies within each radio technology.
- Threshold results depend heavily on the acceptance profile. Limits must be versioned and approved, never inferred from this public dataset.
- Deterministic log parsing can be extremely efficient and accurate when the grammar is controlled; unmatched-line rate is an essential drift indicator.
- Structured instrument exports/metadata are more reliable than OCR. OCR should be a fallback with confidence gates.
- A self-contained HTML report is portable for the POC, while production should store evidence and derived results separately with traceable IDs and hashes.

## Recommended deployment path

### Phase 1 — controlled discovery

- Obtain approved, anonymized examples and completed report templates.
- Inventory formats, owners, classification, retention, and expected volume.
- Agree on field definitions, units, limits, pass logic, and authoritative source.
- Build a labelled benchmark and acceptance criteria.

### Phase 2 — verification-environment pilot

- Add native adapters while preserving raw evidence immutably.
- Deploy on premises or in an approved internal environment.
- Add SSO/RBAC, audit logs, encryption, antivirus scanning, quotas, and retention.
- Run in shadow mode: compare tool output with engineer-approved reports without automatically releasing results.

### Phase 3 — integration and scale

- Connect to test orchestration, result storage, and document management through supported APIs.
- Containerize the stateless processor; move work to a queue for large batches.
- Version parsers, rules, templates, and models in every report manifest.
- Monitor schema drift, unmatched logs, OCR confidence, extraction accuracy, runtime, and overrides.

### Phase 4 — governed intelligence

- Add supervised anomaly/failure prediction only when representative labels exist.
- Maintain a human-review queue and feedback loop.
- Require model/rule validation, rollback, and reproducible decision evidence.

## Security and privacy controls

Treat test logs and images as potentially confidential. Do not send them to public OCR or generative-AI services. Production should implement least privilege, tenant/project isolation, encryption in transit and at rest, malware scanning, content-size limits, safe filename handling, redaction, retention/deletion policy, auditability, dependency scanning, and a threat model covering malicious files and report injection.

