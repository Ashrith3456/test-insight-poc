# Ericsson verification-data pilot checklist

The POC is ready for adaptation, but real Ericsson validation requires authorized data and domain decisions.

## Required inputs

- Anonymized samples for each measurement, log, and image format
- Format/tool/firmware versions and data owners
- Existing report templates and at least several completed examples
- KPI definitions, units, tolerances, and PASS/FAIL/WARNING logic
- Expected batch size, concurrency, runtime target, and retention policy
- Labelled expected extraction results for a protected benchmark
- Security classification and approved execution/storage environment

## Acceptance gates

- Every source file and derived field is traceable in the run manifest.
- No unsupported or low-confidence input can produce an automatic PASS.
- Per-field precision/recall and status confusion matrix meet agreed targets.
- False-PASS rate meets the safety/quality target agreed with verification owners.
- Runtime meets the batch service-level objective at representative volume.
- Verification engineers complete top tasks successfully in usability testing.
- Security, privacy, retention, access-control, and audit requirements are approved.
- Parser, threshold, and template versions are reproducible and rollback-ready.

## Suggested demonstration script

1. Upload one representative batch containing all three modalities.
2. Show validation and normalization of measurement fields and units.
3. Inspect trends, statistical summaries, anomalies, and threshold explanations.
4. Trace an extracted log error and screenshot result to a test ID.
5. Review low-confidence/unmatched evidence.
6. Download the populated report and result tables.
7. Compare results with the labelled engineer-approved report.

